import json
import scrapy

class Bdnews24(scrapy.Spider):
    name = 'Bdnews24'
    allowed_domains =['bangla.bdnews24.com']
    start_urls = ['https://bangla.bdnews24.com/api/v1/collections/111686?item-type=story&offset=0&limit=500']

    def parse(self, response):
        data= json.loads(response.body)
        body = data['items']
        for keyword in body:
            links = ("bangla.bdnews24.com/" + keyword['story']['slug'])

            yield response.follow(links, callback= self.parse_articles)

    def parse_articles(self,response):
        if (response.url).split("/")[3] in ('arts','lifestyle','chobirbhasa','probash','blog','kidz','tube'):
            pass
        else:
            yield{
                'datetime': response.css('div.wBeSy::text').get(),
                'category': (response.url).split("/")[3],
                'url': response.url,
                'title': response.css('h2.MbPT-::text').get(),
                'article': response.css('p::text').getall(),
            
        }

import scrapy
import requests
import re
import json


class BanglatribuneSpider(scrapy.Spider):
    name = 'Banglatribune'
    #allowed_domains = ['banglatribune.com']
    start_urls = ['https://www.banglatribune.com/api/theme_engine/get_ajax_contents?widget=10950&start=20&count=200&page_id=0&author=0&tags=&archive_time=']

    def parse(self, response):
        data= json.loads(response.body)
        body = data['html']
        matches = re.findall(r'"(?<=href=")(.*?)(?=")"', body, re.DOTALL)
        link=[]
        for i in range(len(matches)):
            txt = matches[i]
            x = re.split("\//", txt)
            link.append(x[1])

        for i in range(len(link)):
            yield response.follow("https://"+link[i], callback= self.parse_articles)
    
    def parse_articles(self,response):
        if (response.url).split("/")[3] in ('entertainment','lifestyle','jobs','video'):
            pass
        else:
            yield{
                'datetime': response.css('span.tts_time::attr(content)').get(),
                'category': (response.url).split("/")[3],
                'url': response.url,
                'title': response.css('h1.title::text').get(),
                'article': response.css('p::text').getall(),
            
        }

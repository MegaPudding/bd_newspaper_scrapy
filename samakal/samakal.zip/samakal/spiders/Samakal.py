import scrapy


class SamakalSpider(scrapy.Spider):
    name = 'Samakal'
    allowed_domains = ['samakal.com']
    start_urls = ['https://samakal.com/list/all']
    
    def parse(self, response):
        for link in response.css('a.link-overlay::attr(href)'):
            yield response.follow(link.get(), callback= self.parse_articles)

        next_page = response.css('a.relative::attr(href)').getall()[1]    
        if next_page is not None:
            yield response.follow(next_page, callback=self.parse)
            
    def parse_articles(self,response):
        body=response.css('div.description')
        datetime = response.css('p.detail-time::text').get()
        yield{
            'datetime': datetime.split('|')[0].replace(' প্রকাশ: ',''),
            'category': (response.url).split("/")[3],
            'url': response.url,
            'title': response.css('h1.font-xs-h::text').get(),
            'article': body.css('span::text').getall() + body.css('p::text').getall(),
            
        }
    